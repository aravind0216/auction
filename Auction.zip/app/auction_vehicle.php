<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class auction_vehicle extends Model
{
    //
}
