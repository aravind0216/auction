<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class site_info extends Model
{
    //
}
