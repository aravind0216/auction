<?php $__env->startSection('extra-css'); ?>
     <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/tables/datatable/datatables.min.css">
     <link rel="stylesheet" type="text/css" href="/app-assets/vendors/css/forms/select/select2.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body-section'); ?>

<!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <!-- <div class="content-header row">
                <div class="content-header-left col-12 mb-2 mt-1">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h5 class="content-header-title float-left pr-1 mb-0">Report</h5>
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb p-0 mb-0">
                                    <li class="breadcrumb-item"><a href="/"><i class="bx bx-home-alt"></i></a>
                                    </li>
                                    <li class="breadcrumb-item active">Report
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="content-body">
                <section id="basic-datatable">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-content">
                                    <div class="card-body card-dashboard">
                                        <div class="table-responsive">
<table class="table zero-configuration">
    <thead>
        <tr>
            <th>#</th>
            <th>Images</th>
            <th>Year</th>
            <th>Brand</th>
            <th>Model</th>
            <th>Location</th>
            <th>Odometer</th>
            <th>Doc Type</th>
            <th>Est Retail Value</th>
            <th>Current Bid</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $vehicle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key + 1); ?></td>
            <td><img style="max-height:100px;height:80px;" src="<?php echo e(asset('vehicle_image/').'/'.$row->image); ?>"></td>
            <td><?php echo e($row->year); ?></td>
            <td>
            <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($brand1->id == $row->brand_id): ?>
            <?php echo e($brand1->name); ?>

            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td>
            <?php $__currentLoopData = $car; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($car1->id == $row->car_id): ?>
            <?php echo e($car1->name); ?>

            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td><?php echo e($row->location); ?></td>
            <td><?php echo e($row->odometer); ?></td>
            <td><?php echo e($row->document_type); ?></td>
            <td><?php echo e($row->price); ?></td>
            <td>
                <button>Curent Bid</button>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </tbody>
    <tfoot>
        <tr>
            <th>#</th>
            <th>Images</th>
            <th>Year</th>
            <th>Brand</th>
            <th>Model</th>
            <th>Location</th>
            <th>Odometer</th>
            <th>Doc Type</th>
            <th>Est Retail Value</th>
            <th>Current Bid</th>
        </tr>
    </tfoot>
</table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <!-- END: Content-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
    <script src="/app-assets/vendors/js/tables/datatable/datatables.min.js"></script>
                    <!-- BEGIN: Page Vendor JS-->
    <script src="/app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="/app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js"></script>
    <script src="/app-assets/vendors/js/tables/datatable/buttons.html5.min.js"></script>
    <script src="/app-assets/vendors/js/tables/datatable/buttons.print.min.js"></script>
    <script src="/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js"></script>
    <script src="/app-assets/vendors/js/tables/datatable/pdfmake.min.js"></script>
    <script src="/app-assets/vendors/js/tables/datatable/vfs_fonts.js"></script>
    <!-- END: Page Vendor JS-->
    <script src="/app-assets/js/scripts/datatables/datatable.js"></script>

    <script src="/app-assets/js/scripts/forms/select/form-select2.js"></script>
    <script src="/app-assets/vendors/js/forms/select/select2.full.min.js"></script>

<script type="text/javascript">

$('.find-vehicles').addClass('active');
$('.find-vehicle').addClass('active');

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('member.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Projects\Auction\resources\views/member/find_vehicles.blade.php ENDPATH**/ ?>