<?php $__env->startSection('body-section'); ?>
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('member.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Auction\resources\views/member/dashboard.blade.php ENDPATH**/ ?>